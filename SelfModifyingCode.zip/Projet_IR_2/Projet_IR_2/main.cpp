#include <Windows.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>

#define READ_ADDRESS(x) (*((unsigned int *)x))
using namespace std;

int buffer;

extern "C"
void PrintInt(PVOID msg)
{
	cout << hex << msg << endl;
}

extern "C"
void PrintResult(char* msg)
{
	cout << msg << endl;
}

extern "C"
void clearWR()
{
	cout << "Je suis dans clearWR" << endl;
	//remettre le SMC � la place de clearWR
	//[Adresse(SMC)] = BUFFER

	//Ajouter les droits d'�criture au SMC

	//Cr�er un fichier ou on pourra lire le code du programme sans obfuscation
	//Il contiendra le code de notre programme sans l'instruction du SMC
	//Mais avec le m�me comportement


}

void P()
{
char message1[] = "Bonjour";
char message2[] = "Au revoir";

		__asm
		{
	OldEntry:	MOV BX, 0001H
			XOR eax, eax
			XOR ebx, ebx
			XOR ecx, ecx
			XOR edx, edx		
			XOR EDI, EDI
			MOV ax, 9090h
			NOP
			NOP
			NOP
			NOP
			MOV word ptr[choix1],ax
			NOP
			NOP
			NOP
			NOP
			NOP
			NOP

	choix1:	JMP msg1
	choix2:	JMP msg2

	msg1:	LEA	eax, message1
			JMP aff

	msg2:	LEA	eax, message2
			JMP aff

	aff:	PUSH eax
			call PrintResult
			POP eax

	fin:
		}
}

int filter(unsigned int code, struct _EXCEPTION_POINTERS *ep) {
DWORD OldProtect;
DWORD InstructionSize = 1;
PVOID adresseSMC;
int InstrclearWR;

	cout << "Fonction filter." << endl;

	if (code == EXCEPTION_ACCESS_VIOLATION)
	{
		//Apr�s avoir soulev� l'exception, on sait ou se trouve le code du SMC
		adresseSMC = ep->ExceptionRecord->ExceptionAddress;
		int *ptrSMC = reinterpret_cast<int*>(adresseSMC);
		cout << hex << *ptrSMC << endl;
		buffer = READ_ADDRESS(adresseSMC);
		cout << "ExceptionAddress :" << ep->ExceptionRecord->ExceptionAddress << endl;
		/*cout << "ExceptionCode :" << ep->ExceptionRecord->ExceptionCode << endl;
		cout << "ExceptionFlags :" << ep->ExceptionRecord->ExceptionFlags << endl;
		cout << "ExceptionInformation :" << ep->ExceptionRecord->ExceptionInformation << endl;
		cout << "ExceptionRecord :" << ep->ExceptionRecord->ExceptionRecord << endl;
		cout << "ExceptionNumberParameters :" << ep->ExceptionRecord->NumberParameters << endl << endl;*/
		system("pause");
		if (!VirtualProtect((LPVOID)ptrSMC,2*InstructionSize,PAGE_EXECUTE_READWRITE,&OldProtect))
		{
			cout << "Fail Virtual Protect" << endl;
		}
		
		//*nbr = 2425393296;
		
		//BUFFER = Instruction SMC
		cout << endl;
		cout << "Contenu SMC avant MOV : " << hex << buffer << endl;
		//cout << "clearWR: " <<*clearWR << endl;
		//On met l'appel � la fonction clearWR � la place de l'instruction SMC
		//MOV Adresse(SMC), call clearWR
		
		__asm{		PUSH eax
					PUSH ax
					XOR eax, eax
					MOV eax, fct
					MOV DWORD PTR [InstrclearWR], eax
					POP ax
					POP eax
					JMP endf
					NOP
					NOP
			fct:	call clearWR
					NOP
					NOP
			endf:	NOP
		};

		// benoit
	/*	unsigned int puis=255;

		for (int j = 1 ; j < 25; j++)
			puis *= 2;*/
		
		char *SMC = reinterpret_cast<char*>(adresseSMC);
		char *call = reinterpret_cast<char*>(InstrclearWR);
		cout << "__________________________________" << endl;
		cout << "|Affichage instructions avant NOP|"<< endl;
		cout << "__________________________________"<< endl;
		for (int i = -20; i < 20; i++)
		{
			if (i == 0) cout << "----" << endl;
			cout << hex << int(SMC+i)<< " : " << hex << int (*(SMC+i)) << endl;
		}

		//int *p = reinterpret_cast<int*>(adresseSMC);
		//cout << "benoit : ";
		//for (int i = -5; i < 5; i++)
		//	cout << hex << ((*(p+i)) & (255)) << " ";
		//cout << endl;

		//cout << "benoit : ";
		//for (int i = -5; i < 5; i++)
		//	cout << hex << ((*(p+i)) & (puis)) << " ";
		//cout << endl;


		//int *ptrClearWR = reinterpret_cast<int*>(InstrclearWR);
		//cout << "Contenu pointeur clearWR: " << hex << *ptrClearWR  << " a l'adresse :" << ptrClearWR << endl;
		////Puis on continue l'execution au niveau de l'exception
		////Ce qui va lancer l'appel de la fonction clearWR
		//try
		//{
		//	if (!VirtualProtect(ptrSMC,InstructionSize,PAGE_EXECUTE_READWRITE,&OldProtect))
		//	{
		//		cout << "Fail Virtual Protect" << endl;
		//	}
		//	//int * p = (int *) ep->ExceptionRecord->ExceptionAddress;
		//	//On met 4 NOP � la place du SMC
		//	*ptrSMC = 2425393296;
		//	cout << "ptr SMC apres NOP :" << hex << *ptrSMC << endl;

		//	buffer = READ_ADDRESS(ep->ExceptionRecord->ExceptionAddress);
		//	cout << "Contenu SMC apres NOP : " << hex << buffer << endl;
		//	*ptrSMC = *ptrClearWR;
		//	buffer = READ_ADDRESS(ep->ExceptionRecord->ExceptionAddress);
		//	cout << "Contenu SMC apres MOV : " << hex << buffer << endl;
		//	cout << "Apres " << hex <<*(ptrSMC+1) << endl;
		//	//cout << "p :" << *p << endl;
		//	system("pause");
		//}
		//catch( char *str )
		//{
		//   cout << "Caught some other exception: " << str << "\n";
		//}

		//char *c = reinterpret_cast<char*>(adresseSMC);
		//cout << "benoit : ";
		for (int i = 0; i < 9; i++)
		{
			*(SMC+i) = (char) 144;
		}

		cout << "__________________________________"<< endl;
		cout << "|apr�s insertion NOP             |" << endl;
		cout << "__________________________________"<< endl;
		for (int i = -20; i < 20; i++)
		{
			if (i == 0) cout << "----" << endl;
			cout << hex << int(SMC+i) << " : " << hex << int (*(SMC+i)) << " ";
			cout << endl;
		}

		cout << "__________________________________"<< endl;
		cout << "|Instructions clearWR            |" << endl;
		cout << "__________________________________"<< endl;
		for (int i = -1; i < 10; i++)
		{
			if (i == 0) cout << "----" << endl;
			cout << hex << int(call+i) << " : " << hex << int (*(call+i)) << " ";
			cout << endl;
		}


		cout << "clearWR ecrase le SMC:" << endl;
		for (int i = 0; i < 5; i++)
		{
			*(SMC+i) = *(call+i);
		}

		cout << "__________________________________"<< endl;
		cout << "|Affichage SMC                   |" << endl;
		cout << "__________________________________"<< endl;
		for (int i = -20; i < 20; i++)
		{
			if (i == 0) cout << "----" << endl;
			cout <<  hex << int(SMC+i)<< " : " << hex << int (*(SMC+i)) << " ";
			cout << endl;
		}

		cout << "---------------------------------------------------------------" << endl;
		cout << "Fin fonction filter" << endl;
		return EXCEPTION_CONTINUE_EXECUTION;
	}
	else
	{
		cout << "Exception non trouvee." << endl;
		return EXCEPTION_CONTINUE_SEARCH;
	};
}

void M1()
{
	__try
	{
		cout << "Debut du programme asm." << endl;
		P();
		cout << "Fin du programme asm." << endl;
		system("pause");
	}
	__except(filter(GetExceptionCode(), GetExceptionInformation()))
	{
		
	}

	cout << "Fin traitement exception" << endl;
	system("pause");
}

void InformationException(unsigned int code, struct _EXCEPTION_POINTERS *ep)
{

}




int main( int argc, const char* argv[] )
{
	M1();
}